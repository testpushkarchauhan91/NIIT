package com.favourite.proxy;

public class AuthenticationBean {
	
	private String token;
	
	public AuthenticationBean() {}

	
	public AuthenticationBean(String token) {
		super();
		this.token = token;
	}


	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}


	@Override
	public String toString() {
		return "AuthenticationBean [token=" + token + ", getToken()=" + getToken() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	

}
