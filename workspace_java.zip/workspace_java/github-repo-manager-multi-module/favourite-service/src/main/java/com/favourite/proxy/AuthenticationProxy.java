package com.favourite.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

//@FeignClient(name="currency-exchange-service", url="localhost:8000")
//@FeignClient(name="authentication-service")
//@FeignClient(name="netflix-zuul-api-gateway-server")
//@RibbonClient(name="currency-exchange-service")
public interface AuthenticationProxy {
	// Without Zuul
	//@GetMapping("/currency-exchange/from/{from}/to/{to}")
	// Using Zuul
	@GetMapping("/authenticate")
	public AuthenticationBean retrieveAuthenticationValue();
}