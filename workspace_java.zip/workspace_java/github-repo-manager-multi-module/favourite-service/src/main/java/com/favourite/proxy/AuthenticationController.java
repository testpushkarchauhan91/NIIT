package com.favourite.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class AuthenticationController {

	private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
	
	@GetMapping("/retrieveAuthenticationValue")
	public void retrieveAuthenticationValue() {
		String token = null;
		
		/*
		ResponseEntity<CurrencyConversionBean> responseEntity = new RestTemplate().getForEntity(
				"http://localhost:8000/currency-exchange/from/{from}/to/{to}", CurrencyConversionBean.class,
				uriVariables);

		CurrencyConversionBean response = responseEntity.getBody();

		return new CurrencyConversionBean(response.getId(), from, to, response.getConversionMultiple(), quantity,
				quantity.multiply(response.getConversionMultiple()), response.getPort());
		*/
		
		String url = "http://localhost:8090/authenticate";
		ResponseEntity<AuthenticationBean> responseEntity = new RestTemplate().getForEntity(url, AuthenticationBean.class);
		AuthenticationBean authenticationBean = responseEntity.getBody();
		
		System.out.println(authenticationBean);
		
		//return new AuthenticationBean();
	}
	
}
