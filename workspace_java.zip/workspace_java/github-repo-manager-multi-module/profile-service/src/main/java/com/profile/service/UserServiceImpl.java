package com.profile.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.profile.dao.UserDao;
import com.profile.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;

	@Override
	public void createUser(User user) {
		dao.save(user);
	}
	
	@Override
	public void createUsers(List<User> user) {
		dao.saveAll(user);
	}

	@Override
	public Collection<User> getAllUsers() {
		return dao.findAll();
	}

	@Override
	public Optional<User> findUserById(int id) {
		return dao.findById(id);
	}

	@Override
	public void deleteUserById(int id) {
		dao.deleteById(id);
	}

	@Override
	public void updateUser(User user) {
		dao.save(user);
	}

	@Override
	public void deleteAllUsers() {
		dao.deleteAll();
	}
}