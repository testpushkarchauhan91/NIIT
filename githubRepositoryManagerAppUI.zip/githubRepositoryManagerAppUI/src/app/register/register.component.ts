import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { RegisterBean } from '../model/RegisterBean';
import { Router } from '@angular/router';
import { RegisterService } from '../service/data/register.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  username = '';
  password = '';
  confirmpassword = '';
  message:string;
  errorMessage = 'Invalid Credentials';
  invalidLogin = false;

  loginRef = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]),
    password: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]),
    confirmpassword: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(10)])
  });

  // Dependency Injection
  constructor(private router: Router,
    private registerService: RegisterService) { }

  ngOnInit() {
  }

  checkUser() {
    console.log(this.loginRef.value);
  }

  public registerUser() {
    this.username = this.loginRef.value.username;
    this.password = this.loginRef.value.password;
    this.confirmpassword = this.loginRef.value.confirmpassword;
    let user = new RegisterBean(Math.floor((Math.random() * 10000) + 1), this.username, this.password, this.confirmpassword);
    return this.registerService.registerUser(user).subscribe(response => {
      console.log("User Registered Successfully");
      this.invalidLogin = false;
    },
      error => {
        console.log("Error while registration");
        this.invalidLogin = true;
      });
  }

}