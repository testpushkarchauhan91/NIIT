import { ArraySortPipe } from './array-sort.pipe';

describe('ArraySortPipe', () => {
  it('create an instance', () => {
    const pipe = new ArraySortPipe();
    expect(pipe).toBeTruthy();
  });
});
